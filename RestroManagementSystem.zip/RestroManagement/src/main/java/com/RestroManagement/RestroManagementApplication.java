package com.RestroManagement;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestroManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(RestroManagementApplication.class, args);
	}

}
