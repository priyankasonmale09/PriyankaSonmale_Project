package com.RestroManagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RestroManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
